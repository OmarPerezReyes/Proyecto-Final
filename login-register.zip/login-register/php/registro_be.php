<?php
    //Incluye el archivo "conexion..." para usarlo
    include 'conexion_be.php';

    //Paso de variables del formulario
    $confirmacion = $_POST['confirmacion'];
    $carta_compromiso = $_POST['carta_compromiso'];
    $certificado_vacunacion = $_POST['certificado_vacunacion'];

    //Pre-inserta valores en la tabla
    $query = "INSERT INTO registro(confirmacion, carta_compromiso, certificado_vacunacion) 
              VALUES(''$confirmacion', $carta_compromiso', '$certificado_vacunacion')";

    //Establece conexión a la base de datos e insterta los valores en la tabla
    $ejecutar = mysqli_query($conexion, $query);

    if($ejecutar){
        echo '
            <script>
            alert("Eres nuevo usuario");
            window.location = "../index.php";
            </script>';
    }else{
        echo '
            <script>
            alert("No se pudo realizar la acción. Intente nuevamente.");
            window.location = "../index.php";
            </script>';
    }

    //Cierra la conexión
    mysqli_close($conexion);
?>