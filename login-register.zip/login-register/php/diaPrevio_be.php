<?php
    //Incluye el archivo "conexion..." para usarlo
    include 'conexion_be.php';

    $sintomas = array();
    $productos = array();
    //Paso de variables del formulario
    //$nombre_completo = $_POST['nombre_completo'];
    /*
    $sexo = $_POST['sexo'];
    $edad = $_POST['edad'];
    */
    $fiebre = $_POST['fiebre'];
    $tos = $_POST['tos'];
    $dolor_cabeza['dolor_cabeza'];
    $sintomas = $_POST['sintomas'];
    $salir = $_POST['salir'];
    $visitas = $_POST['visitas'];
    $productos = $_POST['productos'];

    //Pre-inserta valores en la tabla
    $query = "INSERT INTO ingreso_previo(fiebre, tos, dolor_cabeza, sintomas, lugares_publicos, visitas, productos) 
              VALUES('$fiebre', '$tos', '$dolor_cabeza','$sintomas', '$salir', '$visitas', '$productos')";

    //Establece conexión a la base de datos e insterta los valores en la tabla
    $ejecutar = mysqli_query($conexion, $query);

    if($ejecutar){
        echo '
            <script>
            alert("¡Gracias!");
            window.location = "../index.php";
            </script>';
    }else{
        echo '
            <script>
            alert("No se pudo realizar la acción. Intente nuevamente.");
            
            </script>';
    }

    //Cierra la conexión
    mysqli_close($conexion);
?>