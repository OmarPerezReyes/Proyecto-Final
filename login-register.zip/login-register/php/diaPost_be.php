<?php
    include 'conexion_be.php';

    $proceso_ingreso = $_POST['1'];
    $medida_temperatura = $_POST['2'];
    $tunel_sanitizante = $_POST['3'];
    $gel_antibacterial = $_POST['4'];
    $desinfeccion_calzado = $_POST['5'];
    $cubrebocas = $_POST['6'];
    $distancia_social_alumno = $_POST['7'];
    $distancia_social_docentes = $_POST['8'];
    $agua_jabon = $_POST['9'];
    $medidas_implementadas = $_POST['10'];

    $query = "INSERT INTO ingreso_post(proceso_ingreso, medida_temperatura, tunel_sanitizante, gel_antibacterial,
                desinfeccion_calzado, cubrebocas, distancia_social_alumno, distancia_social_docentes, agua_jabon,
                medidas_implementadas) VALUES ('$proceso_ingreso', '$medida_temperatura', '$tunel_sanitizante', '$gel_antibacterial',
                '$desinfeccion_calzado', '$cubrebocas', '$distancia_social_alumno', '$distancia_social_docentes', '$agua_jabon',
                '$medidas_implementadas')";

    $ejecutar = mysqli_query($conexion, $query);

    if($ejecutar){
        echo '
            <script>
            alert("¡Gracias!");
            window.location = "../index.php";
            </script>';
    }else{
        echo '
            <script>
            alert("No se pudo realizar la acción. Intente nuevamente.");
            window.location = "../diaPost.php";
            </script>';
    }

    //Cierra la conexión
    mysqli_close($conexion);
?>