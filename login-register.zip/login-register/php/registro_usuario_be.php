<?php
    //Incluye el archivo "conexion..." para usarlo
    include 'conexion_be.php';

    //Paso de variables del formulario
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];
    //Encripta la contraseña
    $contrasena = hash('sha512', $contrasena);

    //Pre-inserta valores en la tabla
    $query = "INSERT INTO usuarios(nombre_completo, correo, usuario, contrasena) 
              VALUES('$nombre_completo', '$correo','$usuario','$contrasena')";

    //Selecciona sobre la tabla usuarios para obtener coincidencias(ver si se ingresó un valor que ya está)
    $verificar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo ='$correo'");
    $verificar_usuario = mysqli_query($conexion, "SELECT * FROM usuarios WHERE usuario ='$usuario'");

    //Verifica si se quiere ingresar un correo o usario ya existente 
    if(mysqli_num_rows($verificar_correo) > 0 && mysqli_num_rows($verificar_usuario) > 0){
        echo '
            <script>
                alert("El correo y usuario ingresados ya están en uso.");
                window.location = "../index.php";
            </script>
        ';
        exit();
        mysqli_close($conexion);
    }else if(mysqli_num_rows($verificar_correo) > 0){
        echo '
            <script>
                alert("El correo ya está en uso.");
                window.location = "../index.php";
            </script>
        ';
        exit();
        mysqli_close($conexion);
    }else if(mysqli_num_rows($verificar_usuario) > 0){
        echo '
            <script>
                alert("El usuario ingresado ya está en uso.");
                window.location = "../index.php";
            </script>
        ';
        exit();
        mysqli_close($conexion);
    }

    //Establece conexión a la base de datos e insterta los valores en la tabla
    $ejecutar = mysqli_query($conexion, $query);

    if($ejecutar){
        echo '
            <script>
            alert("Eres nuevo usuario");
            window.location = "../index.php";
            </script>';
    }else{
        echo '
            <script>
            alert("No se pudo realizar la acción. Intente nuevamente.");
            window.location = "../index.php";
            </script>';
    }

    //Cierra la conexión
    mysqli_close($conexion);
?>