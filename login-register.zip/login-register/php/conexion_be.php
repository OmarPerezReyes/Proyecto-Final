<?php
    //Esteblee la conexión a la base de datos (tabla usuarios)
    $conexion = mysqli_connect("localhost", "root", "", "login_register");

    /*
    if($conexion){
        echo 'Conexión establecida.';
    }else{
        echo 'No se pudo establecer conexión.';
    }
    */
    
?>