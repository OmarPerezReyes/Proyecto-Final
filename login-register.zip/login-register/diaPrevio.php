<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMS</title>
    <link rel="Icon" href="assets/images/logoSMCSinFondo.png" type="image/png">
    <link rel="stylesheet" href="css/normalize.css">
    <link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="assets/css/estilosAdrian.css">
    <link rel="stylesheet" href="assets/css/fontello.css">
</head>
<body>

  <form action="php/diaPrevio_be.php" method="POST">
  
    <h1>Día previo a asistir</h1>
    
    <fieldset>
      <legend><span class="number">2</span>Favor de llenar los siguientes datos, recuerda que en caso de aprobar tu asistencia, el código solo será válido en las próximas 24 horas</legend>
      <label>1. ¿Tienes fiebre/temperatura?:</label>
      <input type="radio" id="siFT" value="true" name="fiebre"><label for="siFT" class="light">Si</label><br>
      <input type="radio" id="noFT" value="false" name="fiebre"><label for="noFT" class="light">No</label>
      <br><br>
      <label>2. ¿Tienes tos?:</label>
      <input type="radio" id="siT" value="true" name="tos"><label for="siT" class="light">Si</label><br>
      <input type="radio" id="noT" value="false" name="tos"><label for="noT" class="light">No</label>
      <br><br>
      <label>3. ¿Te duele la cabeza?:</label>
      <input type="radio" id="siC" value="true" name="dolor_cabeza"><label for="siC" class="light">Si</label><br>
      <input type="radio" id="noC" value="false" name="dolor_cabeza"><label for="noC" class="light">No</label>
      <br><br>
      <label>4. Durantes los recientes días, has tenido alguno de los siguientes síntomas:</label>
      <input type="checkbox" id="fiebre" value="fiebre" name="sintomas[]"><label for="fiebre" class="light">Fiebre</label><br>
      <input type="checkbox" id="tosSeca" value="tosSeca" name="sintomas[]"><label for="tosSeca" class="light">Tos Seca</label><br>
      <input type="checkbox" id="cansancio" value="cansancio" name="sintomas[]"><label for="cansancio" class="light">Cansancio</label><br>
      <input type="checkbox" id="gustoOl" value="gustoOl" name="sintomas[]"><label for="gustoOl" class="light">Perdida del gusto o el olfato</label><br>
      <input type="checkbox" id="dolorG" value="dolorG" name="sintomas"[]><label for="dolorG" class="light">Dolor de garganta</label><br>
      <input type="checkbox" id="dolorC" value="dolorC" name="sintomas[]"><label for="dolorC" class="light">Dolor de cabeza</label><br>
      <input type="checkbox" id="molestiasD" value="molestiasD" name="sintomas[]"><label for="molestiasD" class="light">Molestias y dolores</label><br>
      <input type="checkbox" id="diarrea" value="diarrea" name="sintomas[]"><label for="diarrea" class="light">Diarrea</label><br>
      <input type="checkbox" id="erupcion" value="erupcion" name="sintomas[]"><label for="erupcion" class="light">Erupción cutánea o pérdida del color de los dedos de las manos o los pies</label><br>
      <input type="checkbox" id="ojosR" value="ojosR" name="sintomas[]"><label for="ojosR" class="light">Ojos rojos o irritados</label><br>
      <input type="checkbox" id="disnea" value="disnea" name="sintomas[]"><label for="disnea" class="light">Dificultad para respirar o disnea</label><br>
      <input type="checkbox" id="perdidaM" value="perdidaM" name="sintomas[]"><label for="perdidaM" class="light">Pérdida de movilidad o del habla o sensación de confusión</label><br>
      <input type="checkbox" id="dolorP" value="dolorP" name="sintomas[]"><label for="dolorP" class="light">Dolor en el pecho</label><br>
      <br>
      <label>5. ¿Con qué frecuencia sales de casa para ir a lugares públicos?</label>
      <input type="radio" id="1-2" value="1-2" name="salir"><label for="1-2" class="light">1-2 veces a la semana</label><br>
      <input type="radio" id="3-4" value="3-4" name="salir"><label for="3-4" class="light">3-4 veces a la semana</label><br>
      <input type="radio" id="5" value="5" name="salir"><label for="5" class="light">5 o mas veces a la semana</label><br>
      <br>
      <label>6. ¿Con qué frecuencia visitas a conocidos, amigos o familia?</label>
      <input type="radio" id="1-2" value="1-2" name="visitas"><label for="1-2" class="light">1-2 veces a la semana</label><br>
      <input type="radio" id="3-4" value="3-4" name="visitas"><label for="3-4" class="light">3-4 veces a la semana</label><br>
      <input type="radio" id="5" value="5" name="visitas"><label for="5" class="light">5 o mas veces a la semana</label><br>
      <br>
      <label>7. Como parte de tu autocuidado, debes llevar los siguientes productos::</label>
      <input type="checkbox" id="gel" value="gel" name="productos[]"><label for="gel" class="light">Gel Antibacterial</label><br>
      <input type="checkbox" id="cubrebocas" value="cubrebocas" name="productos[]"><label for="cubrebocas" class="light">Cubrebocas Extra</label><br>
      <input type="checkbox" id="spray" value="spray" name="productos[]"><label for="spray" class="light">Spray o toallitas desinfectantes</label><br>
    </fieldset>
    <button type="submit">Enviar respuestas</button>
  </form>
  <footer>
    <h2>Nuestras redes sociales</h2>
    <label class="icon-facebook-squared">Facebook</label>
    <label class="icon-twitter">Twitter</label>
    <label class="icon-youtube">Youtube</label>
    <label class="icon-instagram">Instagram</label>
  </footer>
</body>
</html>