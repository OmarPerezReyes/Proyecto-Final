<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMS</title>
    <link rel="Icon" href="assets/images/logoSMCSinFondo.png" type="image/png">
    <link rel="stylesheet" href="css/normalize.css">
    <link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="assets/css/estilosAdrian.css">
    <link rel="stylesheet" href="assets/css/fontello.css">
</head>
<body>

  <form action="php/registro_be.php" method="POST">
  
    <h1>Registro para asistir</h1>
    <h2>El presente formulario solo será aplicado una vez para validar tu asistencia a clases presenciales, en caso de no poder asistir o ya no querer asistir, deberás darte de baja del sistema de asistencia, así mismo si te quieres reincorporar deberás volver a llenar este registro.</h2>
    
    <fieldset>
      <legend><span class="number">1</span>Responder lo siguiente</legend>
      <label>1. ¿Has sido informado sobre los protocolos y requerimientos para que sea posible tu asistencia?:</label>
      <input type="radio" id="siR" value="true" name="confirmacion"><label for="siR" class="light">Si</label><br>
      <input type="radio" id="noR" value="false" name="confirmacion"><label for="noR" class="light">No</label>
      <br><br>
      <label>2. Sube aquí tu carta compromiso:</label>
      <input type="file" id="carta" name="carta_compromiso"><br><br>
      <label>3. Sube aquí tu certificado de vacunación contra la COVID-19:</label>
      <input type="file" id="certificado" name="certificado_vacunacion">
    </fieldset>
    <button type="submit">Enviar respuestas</button>
  </form>
  <footer>
    <h2>Nuestras redes sociales</h2>
    <label class="icon-facebook-squared">Facebook</label>
    <label class="icon-twitter">Twitter</label>
    <label class="icon-youtube">Youtube</label>
    <label class="icon-instagram">Instagram</label>
  </footer>
</body>
</html>