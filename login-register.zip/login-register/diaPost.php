<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMS</title>
    <link rel="Icon" href="assets/images/logoSMCSinFondo.png" type="image/png">
    <link rel="stylesheet" href="css/normalize.css">
    <link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="assets/css/estilosAdrian.css">
    <link rel="stylesheet" href="assets/css/fontello.css">
</head>
<body>

  <form action="php/diaPost_be.php" method="POST">
  
    <h1>Día posterior a asistir</h1>
    
    <fieldset>
      <legend><span class="number">3</span>Favor de contestar las siguientes preguntas con el fin de mejorar nuestro protocolo de asistencia</legend>
      <label>1. ¿El proceso para ingresar a la institución fue de manera ordenada?:</label>
      <input type="radio" id="siMO" value="true" name="1"><label for="siMO" class="light">Si</label><br>
      <input type="radio" id="noMO" value="false" name="1"><label for="noMO" class="light">No</label>
      <br><br>
      <label>2. ¿Te han medido la temperatura con un termómetro infrarrojo digital?:</label>
      <input type="radio" id="siTemp" value="true" name="2"><label for="siTemp" class="light">Si</label><br>
      <input type="radio" id="noTemp" value="false" name="2"><label for="noTemp" class="light">No</label>
      <br><br>
      <label>3. ¿Han activado el túnel sanitizante?:</label>
      <input type="radio" id="siTun" value="true" name="3"><label for="siTun" class="light">Si</label><br>
      <input type="radio" id="noTun" value="false" name="3"><label for="noTun" class="light">No</label>
      <br><br>
      <label>4. ¿Te han aplicado gel antibacterial al ingreso?:</label>
      <input type="radio" id="siGel" value="true" name="4"><label for="siGel" class="light">Si</label><br>
      <input type="radio" id="noGel" value="false" name="4"><label for="noGel" class="light">No</label>
      <br><br>
      <label>5. ¿Han realizado la desinfección de calzado con tapete sanitizante en el ingreso al plantel?:</label>
      <input type="radio" id="siCal" value="true" name="5"><label for="siCal" class="light">Si</label><br>
      <input type="radio" id="noCal" value="false" name="5"><label for="noCal" class="light">No</label>
      <br><br>
      <label>6. ¿Los docentes, personal de apoyo y el alumnado han portado el cubrebocas de manera correcta?:</label>
      <input type="radio" id="siDocent" value="true" name="6"><label for="siDocent" class="light">Si</label><br>
      <input type="radio" id="noDocent" value="false" name="6"><label for="noDocent" class="light">No</label>
      <br><br>
      <label>7. ¿Has respetado la distancia social de al menos 1.5 m?:</label>
      <input type="radio" id="siDis" value="true" name="7"><label for="siDis" class="light">Si</label><br>
      <input type="radio" id="noDis" value="false" name="7"><label for="noDis" class="light">No</label>
      <br><br>
      <label>8. ¿Los docentes han respetado la distancia social de al menos 1.5 m?:</label>
      <input type="radio" id="siDD" value="true" name="8"><label for="siDD" class="light">Si</label><br>
      <input type="radio" id="noDD" value="false" name="8"><label for="noDD" class="light">No</label>
      <br><br>
      <label>9. ¿La universidad cuenta con agua y jabón para la desinfección de manos?:</label>
      <input type="radio" id="siAJ" value="true" name="9"><label for="siAJ" class="light">Si</label><br>
      <input type="radio" id="noAJ" value="false" name="9"><label for="noAJ" class="light">No</label>
      <br><br>
      <label>10. ¿Estás de acuerdo con las medidas implementadas para el regreso a clases seguro?:</label>
      <input type="radio" id="siDea" value="true" name="10"><label for="siDea" class="light">Si</label><br>
      <input type="radio" id="noDea" value="false" name="10"><label for="noDea" class="light">No</label>
      <br><br>
    </fieldset>
    <button type="submit">Enviar respuestas</button>
  </form>
  <footer>
    <h2>Nuestras redes sociales</h2>
    <label class="icon-facebook-squared">Facebook</label>
    <label class="icon-twitter">Twitter</label>
    <label class="icon-youtube">Youtube</label>
    <label class="icon-instagram">Instagram</label>
  </footer>
</body>
</html>